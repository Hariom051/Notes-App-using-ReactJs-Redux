import { useRef } from "react";
import { useNavigate } from "react-router-dom";
import { fetchNotes } from "../Redux/fetchnotes";
import { notesAction } from "../Redux/notes-action";
import { store } from "../Redux/store";
export const Addnote = () => {
  const extract = useRef("");
  const navigate = useNavigate();
  const fn = () => {
    navigate("/viewnote");
    const notes = extract.current.value;
    store.dispatch(notesAction("ADD", notes));
  };
  const loaddata = () => {
    navigate("/viewnote");
    store.dispatch(fetchNotes("FETCH"));
  };
  return (
    <div>
      <h4 className="alert-danger text-center">Add Notes</h4>
      <div className="form-group">
        <label>Write about something</label>
        <textarea className="form-control" rows="10" ref={extract}></textarea>
      </div>
      <br />
      <button onClick={fn} className="btn btn-warning">
        Add
      </button>
      &nbsp; &nbsp;
      <button onClick={loaddata} className="btn btn-primary">
        Load 🚀
      </button>
    </div>
  );
};
