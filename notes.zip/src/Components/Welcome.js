
export const Welcome = () => {
  return (
    <div className="container">
      <h4 className="text-center alert-danger">Welcome to Notes</h4>
      <h2 style={{ fontFamily: "sofia" }}>
        Here, you can add your daily notes, just click on Add note!!🚀🚀🚀🚀
      </h2>
      <br />
      <br />
    </div>
  );
};
