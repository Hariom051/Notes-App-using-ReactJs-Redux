import { useSelector } from "react-redux";
import { useNavigate } from "react-router-dom";

export const Viewnote = () => {
  const notes = useSelector((state) => state.notes);
  console.log(notes);
  const navigate = useNavigate();
  const addnote = () => {
    navigate("/addnote");
  };
  return (
    <div>
      <h4 className="alert-danger text-center">View Notes</h4>
      <p style={{fontFamily:"sofia",fontSize:"19px"}}>
        {notes.map((e, index) => {
          return <p key={index}>🚀{e}</p>;
        })}
      </p >
      <br />
      {notes&& notes.length>0?(<button onClick={addnote} className="btn btn-warning">
        Add more notes
      </button>):<p>Nothing to show</p>}
      
    </div>
  );
};
