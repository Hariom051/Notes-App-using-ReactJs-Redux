import { Merge } from "./Components/Merge";
function App() {
  return <Merge />;
}

export default App;
