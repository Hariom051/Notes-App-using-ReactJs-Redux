export const notesReducer = (state = { notes: [] }, action) => {
  const { type, payload } = action;
  if (type === "ADD") {
    const notes = [...state.notes];
    notes.push(payload);
    return { ...state, notes: notes };
  } else if (type === "FETCH") {
    // Async work
    const notes = [...state.notes];
    payload.data.forEach((e) => {
      notes.push(e);
    });

    return { ...state, notes: notes };
  } else {
    return state;
  }
};
